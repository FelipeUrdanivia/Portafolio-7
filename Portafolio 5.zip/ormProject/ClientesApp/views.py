from django.shortcuts import render, redirect
from .models import Cliente
from .forms import BusquedaClientesForm
from .forms import ClienteForm
from django.contrib import messages

def crear_cliente(request):
    if request.method == 'POST':
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Cliente creado exitosamente.')
            return redirect('buscar_clientes')
    else:
        form = ClienteForm()
    return render(request, 'crear_cliente.html', {'form': form})

def buscar_clientes(request):
    if request.method == 'POST':
        # Creamos una instancia del formulario con los datos de la solicitud
        form = BusquedaClientesForm(request.POST)

        # Verificar si el formulario es válido
        if form.is_valid():
            # Obtener el correo electrónico del formulario
            correo_especifico = form.cleaned_data['correo']

            # Consulta para recuperar clientes mayores de 25 años y con el correo electrónico específico
            clientes_filtrados = Cliente.objects.filter(edad__gt=25, correo=correo_especifico)

            # Renderizar una plantilla con los resultados
            return render(request, 'resultados_clientes.html', {'clientes_filtrados': clientes_filtrados})
    else:
        # Si la solicitud no es POST, creamos una instancia vacía del formulario
        form = BusquedaClientesForm()

    # Renderizar la plantilla del formulario con el formulario
    return render(request, 'formulario_busqueda.html', {'form': form})

def consulta_directa(request):
    if request.method == 'POST':
        # Obtener el correo electrónico del formulario
        correo_especifico = request.POST.get('correo')

        # Ejemplo de consulta SQL directa utilizando el método raw()
        query = "SELECT * FROM ClientesApp_cliente WHERE edad <= %s AND correo = %s"
        clientes_filtrados = Cliente.objects.raw(query, [25, correo_especifico])

        return render(request, 'resultados_clientes.html', {'clientes_filtrados': clientes_filtrados})
    
    else:
        # Si la solicitud no es POST, creamos una instancia vacía del formulario
        form = BusquedaClientesForm()

    # Renderizar la plantilla del formulario con el formulario
    return render(request, 'formulario_busqueda.html', {'form': form})