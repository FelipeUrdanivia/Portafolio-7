from django import forms
from .models import Cliente

class BusquedaClientesForm(forms.Form):
    correo = forms.EmailField(label='Correo electrónico específico')

class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ['nombre', 'edad', 'correo']