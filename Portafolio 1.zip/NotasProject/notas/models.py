from django.db import models

class Alumno(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Asignatura(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Nota(models.Model):
    alumno = models.ForeignKey(Alumno, on_delete=models.CASCADE)
    asignatura = models.ForeignKey(Asignatura, on_delete=models.CASCADE)
    puntaje = models.FloatField()

    def __str__(self):
        return f'{self.alumno.nombre} - {self.asignatura.nombre} ({self.puntaje})'