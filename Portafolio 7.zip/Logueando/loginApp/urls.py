from django.urls import path
from . import views

urlpatterns = [
    path('registro/', views.registro, name='registro'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('para_logueado/', views.para_logueado, name='para_logueado'),
    path('vista_super/', views.vista_super, name='vista_super'),
    path('vista_normal/', views.vista_normal, name='vista_normal'),
]
