from django.urls import path
from . import views

urlpatterns = [
    path('buscar/', views.buscar_clientes, name='buscar_clientes'),
    path('', views.crear_cliente, name='crear_cliente'), 
    path('consulta_directa/', views.consulta_directa, name='consulta_directa'), 
]